using System;
using System.Threading;
using System.Windows.Forms;
using System.Drawing;

class App {
   public static void Main() {
      Application.Run(new ResponsiveForm());
   }
}

// Form-derived class
class ResponsiveForm : Form {

   // Couple of fields to hold references to controls
   TextBox textbox;
   Button button;

   // .ctor to set up the form with child controls
   public ResponsiveForm() {

      // Create a textbox
      this.textbox = new TextBox();      
      this.textbox.Size = new Size(100, 24);
      this.textbox.Location = new Point(10, 10);
      this.Controls.Add(this.textbox);

      // Create a button with event handler
      this.button = new Button();
      this.button.Text = "Do Processing...";
      this.button.Size = new Size(100, 24);
      this.button.Location = new Point(10, 40);
      this.button.Click += new EventHandler(this.OnButtonClick);
      this.Controls.Add(this.button);
   }

   // When the button clicks count up to the number in the textbox
   void OnButtonClick(Object sender, EventArgs args) {
      try {
 
         Int32 num = Int32.Parse(this.textbox.Text);
         // Call asynchronously method that does work that takes time
         WaitCallback doWork = 
            new WaitCallback(this.DoLengthyOperation);
         ThreadPool.QueueUserWorkItem(doWork, num);

      } catch (FormatException) {
         MessageBox.Show(this, 
            "Enter numeric text in TextBox", "Error");
      }
   }

   // Method does arbitrarily lengthy operation
   void DoLengthyOperation(Object param) {
      Int32 num = (Int32) param;
      for (Int32 index = 0; index < num; index++) {
         Console.WriteLine(index); // WriteLine the count
         Thread.Sleep(100);
      }
   }
}