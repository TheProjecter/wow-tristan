Imports System
Imports System.Drawing
Imports System.Threading
Imports System.Windows.Forms

Class App

    Public Shared Sub Main()
        Application.Run(New ResponsiveForm)
    End Sub

End Class

' Form-derived class
Class ResponsiveForm
    Inherits Form

    ' Couple of fields to hold references to controls
    Private button As button
    Private buttonCancel As button
    Private textbox As textbox

    Private cancelled As Boolean

    ' .ctor to set up the form with child controls
    Public Sub New()

        ' Create a textbox
        Me.textbox = New TextBox
        Me.textbox.Size = New Size(100, 24)
        Me.textbox.Location = New Point(10, 10)
        MyBase.Controls.Add(Me.textbox)

        ' Create a button with event handler
        Me.button = New Button
        Me.button.Text = "Do Processing..."
        Me.button.Size = New Size(100, 24)
        Me.button.Location = New Point(10, 40)
        AddHandler Me.button.Click, AddressOf Me.OnButtonClick
        MyBase.Controls.Add(Me.button)

        ' Create a cancel button
        Me.buttonCancel = New Button
        Me.buttonCancel.Text = "CancelOperation"
        Me.buttonCancel.Size = New Size(100, 24)
        Me.buttonCancel.Location = New Point(10, 70)
        AddHandler Me.buttonCancel.Click, AddressOf Me.OnCancelButtonClick
        MyBase.Controls.Add(Me.buttonCancel)

        Me.SetDoingLengthyOperation(0)
    End Sub

    ' When the button clicks count up to the number in the textbox
    Private Sub OnButtonClick(ByVal sender As Object, ByVal args As EventArgs)

        Dim num As Integer
        Dim callback As WaitCallback
        Try
            num = Integer.Parse(Me.textbox.Text)

            Me.SetDoingLengthyOperation(1)

            ' Call asynchronously method that does work that takes time
            callback = AddressOf Me.DoLengthyOperation
            Me.cancelled = False
            ThreadPool.QueueUserWorkItem(callback, num)

        Catch e As FormatException
            MessageBox.Show(Me, "Enter numeric text in TextBox", "Error")
        End Try
    End Sub

    ' Cancel button cancels lengthy operation
    Private Sub OnCancelButtonClick(ByVal sender As Object, ByVal args As EventArgs)
        Me.cancelled = True
    End Sub

    ' Method does arbitrarily lengthy operation
    Private Sub DoLengthyOperation(ByVal param As Object)

        Dim num As Integer
        num = CType(param, Integer)

        Try
            For iter As Integer = 0 To num - 1
                Console.WriteLine(iter)
                Thread.Sleep(100)

                If Me.cancelled Then
                    Return
                End If
            Next iter
        Finally
            ' Re-enable UI
            Me.SetDoingLengthyOperation(0)
        End Try

    End Sub

    ' Enables and disables UI, also makes sure it runs on UI thread
    Private Sub SetDoingLengthyOperation(ByVal working As Boolean)

        Dim delegate1 As HelperDelegate
        Dim args() As Object

        If MyBase.InvokeRequired Then ' // Make sure we run on UI thread
            ' Create a delegate to self
            delegate1 = AddressOf Me.SetDoingLengthyOperation
            ' Roll arguments in an Object array
            args = New Object(0) {}
            args(0) = working

            ' "Recurse once, onto another thread"
            MyBase.Invoke(delegate1, args)
            Return ' Work already done, return
        End If

        ' If this is executing then the call occured on the UI thread
        ' so we can freely access controls
        Me.textbox.Enabled = Not working
        Me.button.Enabled = Not working
        Me.buttonCancel.Enabled = working

    End Sub

    Delegate Sub HelperDelegate(ByVal working As Boolean)

End Class
