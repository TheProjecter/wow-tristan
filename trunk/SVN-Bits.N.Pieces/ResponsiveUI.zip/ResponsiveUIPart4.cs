using System;
using System.Threading;
using System.Windows.Forms;
using System.Drawing;

class App {
   public static void Main() {
      Application.Run(new ResponsiveForm());
   }
}

// Form-derived class
class ResponsiveForm : Form {

   // Couple of fields to hold references to controls
   TextBox textbox;
   Button button;
   Button buttonCancel;

   Boolean cancelled;

   // .ctor to set up the form with child controls
   public ResponsiveForm() {

      // Create a textbox
      this.textbox = new TextBox();      
      this.textbox.Size = new Size(100, 24);
      this.textbox.Location = new Point(10, 10);
      this.Controls.Add(this.textbox);

      // Create a button with event handler
      this.button = new Button();
      this.button.Text = "Do Processing...";
      this.button.Size = new Size(100, 24);
      this.button.Location = new Point(10, 40);
      this.button.Click += new EventHandler(this.OnButtonClick);
      this.Controls.Add(this.button);

      // Create a cancel button
      this.buttonCancel = new Button();
      this.buttonCancel.Text = "CancelOperation";
      this.buttonCancel.Size = new Size(100, 24);
      this.buttonCancel.Location = new Point(10, 70);
      this.buttonCancel.Click += 
         new EventHandler(this.OnCancelButtonClick);
      this.Controls.Add(this.buttonCancel);

      SetDoingLengthyOperation(false);
   }

   // When the button clicks count up to the number in the textbox
   void OnButtonClick(Object sender, EventArgs args) {
      try {
 
         Int32 num = Int32.Parse(this.textbox.Text);

         SetDoingLengthyOperation(true);

         // Call asynchronously method that does work that takes time
         WaitCallback doWork = 
            new WaitCallback(this.DoLengthyOperation);
         cancelled = false;
         ThreadPool.QueueUserWorkItem(doWork, num);

      } catch (FormatException) {
         MessageBox.Show(this, 
            "Enter numeric text in TextBox", "Error");
      }
   }

   // Cancel button cancels lengthy operation
   void OnCancelButtonClick(Object sender, EventArgs args) {
      cancelled = true;
   }

   // Method does arbitrarily lengthy operation
   void DoLengthyOperation(Object param) {
      Int32 num = (Int32) param;
      for (Int32 index = 0; index < num; index++) {
         Console.WriteLine(index); // WriteLine the count
         Thread.Sleep(100);

         if (cancelled)
            break;
      }      

      // Re-enable UI
      this.SetDoingLengthyOperation(false);
   }

   // Enables and disables UI, also makes sure it runs on UI thread
   void SetDoingLengthyOperation(Boolean working) {
      if (this.InvokeRequired) { // Make sure we run on UI thread
         // Create a delegate to self
         HelperDelegate setDoingLengthyOperation = 
            new HelperDelegate(this.SetDoingLengthyOperation);
         // Roll arguments in an Object array
         Object[] arguments = new Object[]{working};
         // "Recurse once, onto another thread"
         this.Invoke(setDoingLengthyOperation, arguments);
         return; // return;
      }

      // If this is executing then the call occured on the UI thread
      // so we can freely access controls
      this.textbox.Enabled = !working;
      this.button.Enabled = !working;
      this.buttonCancel.Enabled = working;
   }

   delegate void HelperDelegate(Boolean working);
}