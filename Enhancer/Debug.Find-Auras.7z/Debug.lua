do return; end
EnDe = AceLibrary("AceAddon-2.0"):new("AceEvent-2.0", "AceDB-2.0", "AceConsole-2.0");

function EnDe:OnInitialize()
	self.Auras = {};
	self:Scan();
end

function EnDe:OnEnable()
	self:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED");
	Enhancer.db.profile.debug = {}
end

function EnDe:OnDisable()
	self:UnregisterAllEvents();
	self:CancelAllScheduledEvents();
end

function EnDe:UNIT_SPELLCAST_SUCCEEDED(unit, spell, rank)
	if (self:IsEventScheduled("EnDe"..(self.lastCast or ""))) then
		self:CancelScheduledEvent("EnDe"..(self.lastCast or ""))
	end
	self.lastCast = spell;
	self:CancelAllScheduledEvents();
	if (not self:IsEventScheduled("EnDe"..spell)) then
		self:ScheduleRepeatingEvent("EnDe"..spell, self.Scan, 0.1, self, spell, GetTime());
	end
	-- Enhancer.Totems[Enhancer.BS["Frost Resistance Totem"]].Buff = Enhancer.BS["Frost Resistance"];
end

function EnDe:Scan(spell, TimerStart)
	local i, a = 1, {};
	while true do
		local name, rank = GetPlayerBuffName(i);
		if not name then break end
		a[name] = true;
		
		if (not self.Auras[name]) then
			self.Auras[name] = true;
			if (spell) then
				self:Print("New Aura:", name);
				if (not Enhancer.db.profile.debug[spell]) then Enhancer.db.profile.debug[spell] = {}; end
				table.insert(Enhancer.db.profile.debug[spell], name);
				self:CancelScheduledEvent("EnDe"..spell)
			end
		end
		
		i = i + 1;
	end
	
	for key, _ in pairs(self.Auras) do
		if (not a[key]) then
			self.Auras[key] = nil; -- Remove
		end
	end
	
	if (TimerStart and ((GetTime() - TimerStart) > 3)) then
		-- last spell prolly didn't give an aura ;)
		if (self:IsEventScheduled("EnDe"..spell)) then
			self:CancelScheduledEvent("EnDe"..spell)
		end
	end
end